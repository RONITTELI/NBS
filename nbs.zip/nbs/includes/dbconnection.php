<?php
// bdconnection.php

// ---- Database connection ----
$con = mysqli_connect("127.0.0.1:3306", "root", "", "nbs");
// alternative: mysqli_connect("127.0.0.1:3308", "root", "", "nbs");
// hosting example: mysqli_connect("sql313.infinityfree.com", "if0_39149356", "eiXRbfbda4", "if0_39149356_nbs");

$apiKey = "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"; // Your OpenAI API key here


if (mysqli_connect_errno()) {
    echo "Connection Fail: " . mysqli_connect_error();
    exit;
}

// // ---- OpenAI Configuration ----
// define('OPENAI_API_KEY', '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');

// // Model settings
// define('OPENAI_MODEL', 'gpt-4o-mini');   // choose model
// define('OPENAI_MAX_TOKENS', 512);

// // ---- Allowed schema for chatbot (safe tables only) ----
// $ALLOWED_SCHEMA = [
//   'notices' => ['id','category','class','title','content','created_at','status','created_by','file_path','views'],
//   'tblcategory' => ['id','categoryname','creationdate'],
//   'tblinquiries' => ['id','notice_id','category','user_id','full_name','email','mobile_number','subject','message','created_at'],
//   'events' => ['id','title','event_date','description','notice_id'],
//   'polls' => ['id','question','created_at','notice_id','class','course'],
//   'poll_options' => ['id','poll_id','option_text'],
//   'poll_votes' => ['id','poll_id','option_id','user_id','voted_at'],
//   'students' => ['id','student_name','email','uid','class','course','phone','address','dob','gender','reg_date']
// ];

// // Tables that must never be exposed
// $BLACKLIST_TABLES = ['tbladmin','images'];
// ?>


  
